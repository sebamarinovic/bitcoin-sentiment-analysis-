# Data

Este directorio contiene los datos necesarios para el análisis. Los archivos no se incluyen en el repositorio debido a su tamaño.

## Datasets Requeridos

### 1. Tweets de Bitcoin

**Fuente:** Kaggle  
**Dataset:** [Bitcoin Sentiment Analysis Twitter Data](https://www.kaggle.com/datasets/gautamchettiar/bitcoin-sentiment-analysis-twitter-data)  
**Archivo:** `bitcoin_tweets1000000.csv`  
**Tamaño:** ~500 MB  
**Registros:** 1,000,025 tweets

#### Descarga automática con kagglehub:

```python
from kagglehub import dataset_download
path = dataset_download("gautamchettiar/bitcoin-sentiment-analysis-twitter-data")
print(f"Dataset descargado en: {path}")
```

#### Descarga manual:

1. Ir a [Kaggle Dataset](https://www.kaggle.com/datasets/gautamchettiar/bitcoin-sentiment-analysis-twitter-data)
2. Descargar el archivo CSV
3. Colocar en este directorio como `bitcoin_tweets1000000.csv`

### 2. Datos de Precios OHLCV

**Fuente:** Binance  
**Par:** BTC/USDT  
**Frecuencia:** Horaria (1h)  
**Período:** 5 Febrero 2021 - 21 Agosto 2021  
**Archivo:** `BTCUSDT_1h_2021-02-05_2021-08-21.csv`

#### Columnas esperadas:

| Columna | Descripción |
|---------|-------------|
| date | Timestamp UTC |
| open | Precio de apertura |
| high | Precio máximo |
| low | Precio mínimo |
| close | Precio de cierre |
| volume | Volumen en BTC |

#### Obtener datos de Binance:

```python
import pandas as pd
from binance.client import Client

client = Client()
klines = client.get_historical_klines(
    "BTCUSDT", 
    Client.KLINE_INTERVAL_1HOUR,
    "5 Feb, 2021",
    "21 Aug, 2021"
)

df = pd.DataFrame(klines, columns=[
    'date', 'open', 'high', 'low', 'close', 'volume',
    'close_time', 'quote_volume', 'trades', 
    'taker_buy_base', 'taker_buy_quote', 'ignore'
])
df['date'] = pd.to_datetime(df['date'], unit='ms')
df = df[['date', 'open', 'high', 'low', 'close', 'volume']]
df.to_csv('BTCUSDT_1h_2021-02-05_2021-08-21.csv', index=False)
```

## Estructura de Archivos

```
data/
├── README.md                              # Este archivo
├── bitcoin_tweets1000000.csv              # Tweets (descargar de Kaggle)
└── BTCUSDT_1h_2021-02-05_2021-08-21.csv   # Precios OHLCV (descargar de Binance)
```

## Notas

- Los archivos CSV no se incluyen en el repositorio (ver `.gitignore`)
- Asegúrate de tener suficiente espacio en disco (~1 GB)
- El procesamiento de tweets con FinBERT requiere GPU para tiempos razonables
